/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personatges;

/**
 *
 * @author Felip
 */
public class Huma extends Jugador {

    public Huma(String nom, int atac, int defensa, int vides) {
        super(nom, atac, defensa, (vides > 100) ? 100 : vides);
        System.out.println("Sóc el constructor de Huma i vaig a fer un " + this.getClass().getSimpleName());

    }
}
