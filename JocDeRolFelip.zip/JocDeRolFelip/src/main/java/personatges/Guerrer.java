/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personatges;

/**
 *
 * @author Felip
 */
public class Guerrer extends Huma {

    public Guerrer(String nom, int atac, int defensa, int vides) {
        super(nom, atac, defensa, vides);
        System.out.println("Sóc el constructor de Guerrer i vaig a fer un " + this.getClass().getSimpleName());
    }

    @Override
    public void ataca(Jugador jugador) {
        int vida = jugador.getVides();
        if ((this.getPuntsAtac() - jugador.getPuntsDefensa() < 5)) {
            jugador.setVides(vida);
        } else {
            super.ataca(jugador);
        }
    }
}
