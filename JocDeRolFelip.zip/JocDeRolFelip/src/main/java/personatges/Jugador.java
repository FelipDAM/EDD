/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package personatges;

import altres.Equip;
import altres.Poder;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Felip
 */
public class Jugador {

    private Equip equip;
    private String nom;
    private int puntsAtac;
    private int puntsDefensa;
    private int vides;
    static public int videsInicials = 200;
    private ArrayList<Poder> poders = new ArrayList();

    public void posa(Poder p) {

        poders.add(p);

    }

    public void lleva(Poder p) {

        poders.remove(p);
    }

    public Equip getEquip() {
        return equip;
    }

    public void setEquip(Equip equip) {

        if ((equip == null && this.equip != null)) {
            
            this.equip = null;
            this.equip.lleva(this.nom);

        } else {

            if (equip != null) {
                this.equip = equip;
                equip.jugadors.add(this);
            }
        }
    }

    @Override
    public boolean equals(Object obj
    ) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Jugador)) {
            return false;
        }
        final Jugador other = (Jugador) obj;
        return Objects.equals(this.nom, other.nom);
    }

    public Jugador(String nom, int atac, int defensa, int vides) {
        System.out.println("Sóc el constructor de Jugador i vaig a fer un " + this.getClass().getSimpleName());
        this.nom = nom;
        this.puntsAtac = atac;
        this.puntsDefensa = defensa;
        this.vides = vides;
    }

    public String getNom() {
        return nom;
    }

    protected void setNom(String nom) {
        this.nom = nom;
    }

    public int getPuntsAtac() {
        return puntsAtac;

    }

    protected void setPuntsAtac(int PuntsAtac) {
        this.puntsAtac = PuntsAtac;
    }

    public int getPuntsDefensa() {
        return puntsDefensa;
    }

    protected void setPuntsDefensa(int PuntsDefensa) {
        this.puntsDefensa = PuntsDefensa;
    }

    public int getVides() {
        return vides;
    }

    protected void setVides(int vides) {
        this.vides = vides;
    }

    @Override
    public String toString() {
        String poderets = "";
        for (Poder poder : poders) {
            poderets += "-" + poder.toString() + "\n";
        }
        if (equip != null) {
            return this.nom + "[ " + equip.getNom() + " ]" + "(PA:" + this.puntsAtac + ", PD:" + this.puntsDefensa + ", PV:" + this.vides + ")\n" + (poders.size() > 0 ? poderets : "");
        }
        return this.nom + "[ " + equip + " ]" + "(PA:" + this.puntsAtac + ", PD:" + this.puntsDefensa + ", PV:" + this.vides + ")\n" + (poders.size() > 0 ? poderets : "");

    }

    protected void esColpejatAmb(int QuantitatPA) {
        int pd = 0;
        for (Poder poder : poders) {
            pd += poder.getBonusDefensa();
        }
        int DefensaEscut = (QuantitatPA) - (this.puntsDefensa + pd);
        if (DefensaEscut < 0) {
            DefensaEscut = 0;
        }

        int VidesRestants = this.vides - DefensaEscut;
        if (VidesRestants < 0) {
            VidesRestants = 0;
        }

        System.out.println(this.nom + " és colpejat amb " + QuantitatPA + " punts d'atac i es defén amb " + (this.puntsDefensa + pd) + " punts. Vides: " + this.vides + " - " + DefensaEscut + " = " + VidesRestants);

        this.vides = VidesRestants;

    }

    public void ataca(Jugador jugador) {
        int pa = 0;
        for (Poder poder : poders) {
            pa += poder.getBonusAtac();
        }
        System.out.println(this.toString());
        System.out.println(jugador.toString());

        this.esColpejatAmb(jugador.puntsAtac);
        jugador.esColpejatAmb(this.puntsAtac + pa);
        System.out.println();
        System.out.println(this.toString());
        System.out.println(jugador.toString());

    }

}
