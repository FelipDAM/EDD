/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package personatges;

/**
 *
 * @author Felip
 */
public class Alien extends Jugador {

    public Alien(String nom, int atac, int defensa, int vides) {
        super(nom, atac, defensa, vides);
        System.out.println("Sóc el constructor de Alien i vaig a fer un " + this.getClass().getSimpleName());

    }

    @Override
    public void ataca(Jugador jugador) {
        if (this.getVides() > 20) {
            this.setPuntsAtac(this.getPuntsAtac() + 3);
            this.setPuntsDefensa(this.getPuntsDefensa() - 3);
        }
        super.ataca(jugador);
        if (this.getVides() > 20) {
            this.setPuntsAtac(this.getPuntsAtac() - 3);
            this.setPuntsDefensa(this.getPuntsDefensa() + 3);
        }
    }

}
