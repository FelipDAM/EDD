/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package altres;

import inici.Equips;
import inici.Jugadors;
import java.util.ArrayList;
import java.util.Objects;
import personatges.Jugador;

/**
 *
 * @author Felip
 */
public class Equip {

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Equip other = (Equip) obj;

        return Objects.equals(this.nom, other.nom);
    }

    private String nom;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Equip(String nom) {
        this.nom = nom;
    }
    public ArrayList<Jugador> jugadors = new ArrayList();

    public void posa(Jugador j) {
        if (jugadors.contains(j)) {
            System.out.println("Ja estic en la llista");
        } else {
            if (j.getEquip() == null) {
                j.setEquip(this);
            }
        }
    }

    public void lleva(String NomJugador) {
        Jugador jugesb = new Jugador(NomJugador, 0, 0, 0);
        if (this.jugadors.contains(jugesb)) {
            jugesb = jugadors.get(jugadors.indexOf(jugesb));
            this.jugadors.remove(jugesb);
            jugesb.setEquip(null);

        }
    }

    @Override
    public String toString() {
        String cadena = "Equip " + nom + "\n";

        for (Jugador jugador : jugadors) {
            cadena += "-" + jugador.toString() + "\n";
        }

        return cadena;
    }

}
