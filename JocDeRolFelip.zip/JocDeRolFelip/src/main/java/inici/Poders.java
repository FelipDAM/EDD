/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inici;

import Teclat.*;
import altres.Poder;
import static inici.JocDeRol.menuConfiguracio;
import java.util.ArrayList;
import personatges.Jugador;

/**
 *
 * @author Felip
 */
public class Poders {

    static ArrayList<Poder> llista = new ArrayList();

    static public void menu() {
        int opcio = Teclat.lligOpcio("PODERS", "Crear", "Consultar", "Eliminar");
        switch (opcio) {
            case 1:
                crear();
                menu();
                break;
            case 2:
                consultar();
                menu();
                break;
            case 3:
                eliminar();
                menu();
                break;
            case 0:
                menuConfiguracio();
                break;
        }
    }

    static void crear() {
        String nom = Teclat.lligString("Dis-me el nom del poder que vols crear");
        int ba = Teclat.lligInt("Bonus d'atac del poder");
        int bd = Teclat.lligInt("Bonus de defensa del poder");

        Poder p = new Poder(nom, ba, bd);
        if (llista.contains(p)) {
            System.out.println("La llista ja conté este poder");
        } else {
            llista.add(p);
            System.out.println("Poder afegit");
        }
    }

    static void consultar() {
        if (Poders.llista.size() < 1) {
            System.out.println("La llista de poders està buida");
        } else {
            for (Poder poder : llista) {
                System.out.println(poder);
            }
        }
    }

    static void eliminar() {
        String nom = Teclat.lligString("Dis-me el nom del poder que vols crear");
       
        Poder p = new Poder(nom, 0, 0);
        if (!llista.contains(p)) {
            System.out.println("El poder no es troba en la llista");
        } else {
            llista.remove(p);
            for (Jugador jugpoder : Jugadors.llista) {
                jugpoder.lleva(p);
            }
                
            }
            
           
                
            System.out.println("Poder esborrat");
        }
    }


