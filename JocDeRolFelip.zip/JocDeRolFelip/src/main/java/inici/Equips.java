/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inici;

import Teclat.*;
import altres.Equip;
import static inici.JocDeRol.menuConfiguracio;
import java.util.ArrayList;
import personatges.Jugador;

/**
 *
 * @author Felip
 */
public class Equips {

    static ArrayList<Equip> llista = new ArrayList();

    static public void menu() {
        int opcio = Teclat.lligOpcio("EQUIPS", "Crear", "Consultar", "Eliminar");
        switch (opcio) {
            case 1:
                crear();
                menu();
                break;
            case 2:
                consultar();
                menu();
                break;
            case 3:
                eliminar();
                menu();
                break;
            case 0:
                menuConfiguracio();
                break;
        }
    }

    static void crear() {
        String nom = Teclat.lligString("Dis-me el nom de l'equip que vols crear");
        Equip e = new Equip(nom);
        if (llista.contains(e)) {
            System.out.println("La llista ja conté este equip");
        } else {
            llista.add(e);
            System.out.println("Equip afegit");
        }
    }

    static void consultar() {
       if(Equips.llista.size()<1){
           System.out.println("La llista està buida");
           
       }else{
           for (Equip equip : llista) {
               System.out.println(equip);
           }
       }
    }
    static void eliminar() {
        String nom = Teclat.lligString("Dis-me el nom de l'equip que vols eliminar");
        Equip e = new Equip(nom);
        if (!llista.contains(e)) {
            System.out.println("Este equip no existeix");
        } else {
            e = Equips.llista.get(Equips.llista.indexOf(e));
            for (Jugador jugador : Jugadors.llista) {
                 if (jugador.getEquip() != null && jugador.getEquip().equals(e)) {
                 e.lleva(jugador.getNom());
                 }
            }
            llista.remove(e);
            System.out.println("Equip esborrat");
        }
    }
}
