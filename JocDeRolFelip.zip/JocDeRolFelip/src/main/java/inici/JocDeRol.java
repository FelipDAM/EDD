/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inici;

import personatges.*;
import Teclat.*;
import altres.Equip;
import altres.Poder;
import static inici.Jugadors.llista;
import java.util.Random;

/**
 *
 * @author Felip
 */
public class JocDeRol {

    public static void main(String[] args) {
        //JOC DE ROL FELIP LLORET.
        //provaFase1();
        //provaFase2();
        //provaFase3();
       //provaFase4();
        //provaFase5();
        int opcio = 1;
        while (opcio != 0) {
            opcio = Teclat.lligOpcio("JOC DE ROL", "Configuració", "Jugar");

            switch (opcio) {
                case 1:
                    menuConfiguracio();
                    break;
                case 2:
                    jugar();
                    break;
                case 0:
                    break;
            }
        }
    }

    private static void provaFase1() {

        //CREA UN JUGADOR DE CADA TIPUS
        System.out.println("Vaig a crear un Huma");
        Jugador huma1 = new Huma("PEDRO", 22, 20, 40);
        System.out.println("Vaig a crear un Guerrer");
        Jugador guerrer1 = new Guerrer("asdasd", 22, 22, 22);
        System.out.println("Vaig a crear un Alien");
        Jugador alien1 = new Alien("asdasd", 22, 22, 22);
    }

    private static void provaFase2() {

        //CREA JUGADORS
        Jugador huma2 = new Huma("PEPET", 40, 30, 120);
        Jugador alien2 = new Alien("Pepenet", 60, 20, 60);
        Jugador guerrer2 = new Guerrer("asdasdsa", 60, 20, 60);
        //MOSTRA DADES
        System.out.println(alien2);
        System.out.println(huma2);
        System.out.println(guerrer2);
        //ATACS
        huma2.ataca(alien2);
        guerrer2.ataca(huma2);
        alien2.ataca(guerrer2);
    }

    private static void provaFase3() {

        //CREEM UN JUGADORS DE CADA TIPUS PER VORE COMPORTAMENTS
        Jugador huma3 = new Huma("Joaquin", 70, 40, 120);
        Jugador alien3 = new Alien("Manolo", 60, 50, 60);
        Jugador guerrer3 = new Guerrer("Manolo", 60, 50, 60);

        huma3.ataca(alien3);
        guerrer3.ataca(huma3);
        alien3.ataca(guerrer3);
    }

    private static void provaFase4() {

        //CREEM JUGADORS I ELS I ASSIGNEM I LLEVEM UN EQUIP
        Jugador huma4 = new Huma("Joaquin", 70, 40, 60);
        Jugador alien4 = new Alien("Manolo", 60, 50, 60);

        Equip e1 = new Equip("Hola");

        System.out.println("Soc huma sense equip " + huma4);

        e1.posa(huma4);
        System.out.println("Soc huma amb equip " + huma4);
        
        System.out.println("Jo soc l'equip "+ e1);
  
        e1.lleva("Joaquin");
        System.out.println("Soc jo sense equip "+huma4);
        System.out.println("Soc l'equip "+e1);

        //Ja està en un equip
        //e2.posa(alien4);

    }

    private static void provaFase5() {

        //CREEM JUGADORS I ELS I ASSIGNEM PODERS  
        Jugador huma5 = new Huma("Joaquin", 70, 40, 60);
        Jugador alien5 = new Alien("Manolo", 60, 50, 60);

        huma5.posa(new Poder("Escut", 20, 50));

        huma5.ataca(alien5);
    }

    public static void menuConfiguracio() {
        int opcio = Teclat.lligOpcio("CONFIGURACIÓ", "Jugadors", "Equips", "Poders");
        switch (opcio) {
            case 1:
                Jugadors.menu();
                break;
            case 2:
                Equips.menu();
                break;
            case 3:
                Poders.menu();
                break;
        }
    }

    public static void jugar() {
        if (llista.size() < 2) {
            System.out.println("No hi han suficients jugadors en la llista");
            return;
        }

        Random random = new Random();

        do {
            Jugador jugador1 = llista.get(random.nextInt(llista.size()));
            Jugador jugador2;
            do {
                jugador2 = llista.get(random.nextInt(llista.size()));
            } while (jugador1 == jugador2);

            jugador1.ataca(jugador2);

            if (jugador1.getVides() < 1) {
                System.out.println(jugador1.getNom() + " ha mort.");
                llista.remove(jugador1);
            }
            if (jugador2.getVides() < 1) {
                System.out.println(jugador2.getNom() + " ha mort.");
                llista.remove(jugador2);
            }

        } while (llista.size() > 1);

        if (llista.size() == 1) {
            Jugador guanyador = llista.get(0);
            System.out.println("----------------------");
            System.out.println(guanyador.getNom() + " HA GUANYAT LA PARTIDA!!");
            System.out.println("----------------------");
            Jugadors.llista.remove(guanyador);
        } else {
            System.out.println("----------------------");
            System.out.println("HA SIGUT UN AMASACRE");
            System.out.println("----------------------");
        }
        System.out.println();
    }
}
