/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inici;

import java.util.ArrayList;
import personatges.Jugador;
import Teclat.*;
import altres.Equip;
import altres.Poder;
import static inici.JocDeRol.menuConfiguracio;
import java.util.Objects;
import personatges.Alien;
import personatges.Guerrer;
import personatges.Huma;

/**
 *
 * @author Felip
 */
public class Jugadors {

    static ArrayList<Jugador> llista = new ArrayList();

    static public void menu() {
        int opcio = Teclat.lligOpcio("JUGADORS", "Crear", "Consultar", "Eliminar", "Assignar a equip", "Llevar d'equip", "Assignar poder");
        switch (opcio) {
            case 1:
                char tipus = Teclat.lligChar("Tipus de jugador a crear", "HGA");
                String nom = Teclat.lligString("Nom del Jugador");
                int PuntsAtac = Teclat.lligInt("Punts d'atac del jugador", 1, 100);
                int PuntsDefensa = 100 - PuntsAtac;

                switch (tipus) {

                    case 'A', 'a':
                        Jugador alien = new Alien(nom, PuntsAtac, PuntsDefensa, Jugador.videsInicials);
                        if (llista.contains(alien)) {
                            System.out.println("Ja estic en la llista");
                        } else {
                            Jugadors.llista.add(alien);
                        }
                        break;
                    case 'G', 'g':
                        Jugador guerrer = new Guerrer(nom, PuntsAtac, PuntsDefensa, Jugador.videsInicials);
                        if (llista.contains(guerrer)) {
                            System.out.println("Ja estic en la llista");
                        } else {
                            Jugadors.llista.add(guerrer);
                        }
                        break;
                    case 'H', 'h':
                        Jugador huma = new Huma(nom, PuntsAtac, PuntsDefensa, Jugador.videsInicials);
                        if (llista.contains(huma)) {
                            System.out.println("Ja estic en la llista");
                        } else {
                            Jugadors.llista.add(huma);
                        }
                        break;
                }
                menu();
                break;

            case 2:
                if (Jugadors.llista.size() < 1) {
                    System.out.println("La llista de jugadors està buida");
                } else {
                    for (Jugador jugador : llista) {
                        System.out.println(jugador);
                    }
                }
                menu();
                break;
            case 3:
                String jugesborrat = Teclat.lligString("Dis-me el nom del jugador a esborrar");
                Jugador jugesb = new Jugador(jugesborrat, 0, 0, 0);
                if (llista.contains(jugesb)) {
                    llista.remove(jugesb);
                }
                menu();
                break;
            case 4:
                nom = Teclat.lligString("Nom del jugador");
                String nomequip = Teclat.lligString("Nom de l'equip");
                Equip e = new Equip(nomequip);
                Jugador j = new Jugador(nom, 0, 0, 0);

                if (Equips.llista.contains(e)) {
                    e = Equips.llista.get(Equips.llista.indexOf(e));
                    if (Jugadors.llista.contains(j)) {
                        j = Jugadors.llista.get(Jugadors.llista.indexOf(j));
                        e.posa(j);
                    } else {
                        System.out.println("El jugador no es troba");
                    }

                } else {
                    System.out.println("El equip no es troba");
                }
                menu();
                break;
            case 5:
                nom = Teclat.lligString("Nom del jugador");
                nomequip = Teclat.lligString("Nom de l'equip");
                e = new Equip(nomequip);
                try {
                    e = Equips.llista.get(Equips.llista.indexOf(e));
                    e.lleva(nom);
                }
                catch(Exception error){
                   
                }
                    menu();
                    break;

                
        
    

case 6:
                nom = Teclat.lligString("Nom del jugador");
                String nompoder = Teclat.lligString("Nom del poder");
                j = new Jugador(nom, 0, 0, 0);
                Poder p = new Poder(nompoder, 0, 0);

                if (Poders.llista.contains(p)) {
                    p = Poders.llista.get(Poders.llista.indexOf(p));

                    if (Jugadors.llista.contains(j)) {
                        j = Jugadors.llista.get(Jugadors.llista.indexOf(j));
                        j.posa(p);
                    } else {
                        System.out.println("El jugador no es troba a la llista");
                    }
                } else {
                    System.out.println("El poder no es troba a la llista");
                }
                menu();
                break;
            case 0:
                menuConfiguracio();
                break;
        }
    }

}
